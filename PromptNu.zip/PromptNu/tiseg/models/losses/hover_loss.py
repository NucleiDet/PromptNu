import torch
import torch.nn as nn
import torch.nn.functional as F


def msge_loss(true, pred, focus):
    """Calculate the mean squared error of the gradients of
    horizontal and vertical map predictions. Assumes
    channel 0 is Vertical and channel 1 is Horizontal.

    Args:
        true:  ground truth of combined horizontal
               and vertical maps
        pred:  prediction of combined horizontal
               and vertical maps
        focus: area where to apply loss (we only calculate
                the loss within the nuclei)

    Returns:
        loss:  mean squared error of gradients

    """
    ###ori###
    # def get_sobel_kernel(size):
    ###ruby###
    def get_sobel_kernel(size, devices):
    ####
        """Get sobel kernel with a given size."""
        assert size % 2 == 1, "Must be odd, get size=%d" % size

        h_range = torch.arange(
            -size // 2 + 1,
            size // 2 + 1,
            dtype=torch.float32,
            ###ori###
            # device="cuda",
            ###ruby###
            device=devices,
            ####
            requires_grad=False,
        )
        v_range = torch.arange(
            -size // 2 + 1,
            size // 2 + 1,
            dtype=torch.float32,
            ###ori###
            # device="cuda",
            ###ruby###
            device=devices,
            ####
            requires_grad=False,
        )
        h, v = torch.meshgrid(h_range, v_range)
        kernel_h = h / (h * h + v * v + 1.0e-15)
        kernel_v = v / (h * h + v * v + 1.0e-15)
        return kernel_h, kernel_v

    ###ori###
    # def get_gradient_hv(hv):
    #     """For calculating gradient."""
    #     kernel_h, kernel_v = get_sobel_kernel(5)
    ###ruby###
    def get_gradient_hv(hv, devices):
        """For calculating gradient."""
        kernel_h, kernel_v = get_sobel_kernel(5, devices)
    ####
        kernel_h = kernel_h.view(1, 1, 5, 5)  # constant
        kernel_v = kernel_v.view(1, 1, 5, 5)  # constant

        kernel_v = kernel_v.to(hv.device)
        kernel_h = kernel_h.to(hv.device)
        
        h_ch = hv[:, 0].unsqueeze(1)  # Nx1xHxW
        v_ch = hv[:, 1].unsqueeze(1)  # Nx1xHxW

        # can only apply in NCHW mode
        h_dh_ch = F.conv2d(h_ch, kernel_h, padding=2)
        v_dv_ch = F.conv2d(v_ch, kernel_v, padding=2)
        dhv = torch.cat([h_dh_ch, v_dv_ch], dim=1)
        dhv = dhv.permute(0, 2, 3, 1).contiguous()  # to NHWC
        return dhv

    focus = (focus[..., None]).float()  # assume input NHW
    focus = torch.cat([focus, focus], axis=-1)
    ##ori###
    # true_grad = get_gradient_hv(true)
    # pred_grad = get_gradient_hv(pred)
    ###ruby###
    true_grad = get_gradient_hv(true, focus.device)
    pred_grad = get_gradient_hv(pred, focus.device)
    ####
    loss = pred_grad - true_grad

    loss = focus * (loss * loss)
    # artificial reduce_mean with focused region
    loss = loss.sum() / (focus.sum() + 1.0e-8)
    return loss


class GradientMSELoss(nn.Module):

    def forward(self, logit, target, focus):
        return msge_loss(target, logit, focus)
