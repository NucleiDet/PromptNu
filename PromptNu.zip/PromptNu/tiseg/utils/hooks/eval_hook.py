import torch.distributed as dist
from mmcv.runner import DistEvalHook as _DistEvalHook
from mmcv.runner import EvalHook as _EvalHook
from torch.nn.modules.batchnorm import _BatchNorm

from tensorboardX import SummaryWriter
writer = SummaryWriter(log_dir='runs')

class EvalHook(_EvalHook):
    """Single GPU EvalHook, with efficient test support.
    Args:
        by_epoch (bool): Determine perform evaluation by epoch or by iteration.
            If set to True, it will perform by epoch. Otherwise, by iteration.
            Default: False.
        eval_start (int, optional): The evaluate start iteration (When this arg
            is set to None, this arg will be invalidate.). Default: None
    Returns:
        list: The prediction results.
    """

    greater_keys = ['mIoU', 'mAcc', 'aAcc']

    def __init__(self, *args, custom_intervals=None, custom_milestones=None, by_epoch=False, **kwargs):
        super().__init__(*args, by_epoch=by_epoch, **kwargs)
        if custom_intervals is not None and custom_milestones is not None:
            self.custom_intervals = custom_intervals
            self.custom_milestones = custom_milestones
        else:
            self.custom_intervals = []
            self.custom_milestones = []

    def _should_evaluate(self, runner):
        """Judge whether to perform evaluation.
        Here is the rule to judge whether to perform evaluation:
        1. It will not perform evaluation during the epoch/iteration interval,
           which is determined by ``self.interval``.
        2. It will not perform evaluation if the start time is larger than
           current time.
        3. It will not perform evaluation when current time is larger than
           the start time but during epoch/iteration interval.
        Returns:
            bool: The flag indicating whether to perform evaluation.
        """
        if self.by_epoch:
            current = runner.epoch
            check_time = self.every_n_epochs
        else:
            current = runner.iter
            check_time = self.every_n_iters

        interval = self.interval
        for i, m in zip(self.custom_intervals, self.custom_milestones):
            if (current + 1) >= m:
                interval = i
            else:
                break

        if self.start is None:
            if not check_time(runner, interval):
                # No evaluation during the interval.
                return False
        elif (current + 1) < self.start:
            # No evaluation if start is larger than the current time.
            return False
        else:
            # Evaluation only at epochs/iters 3, 5, 7...
            # if start==3 and interval==2
            if (current + 1 - self.start) % interval:
                return False

        return True

    def evaluate(self, runner, results):
        """Evaluate the results.

        Args:
            runner (:obj:`mmcv.Runner`): The underlined training runner.
            results (list): Output results.
        """
        eval_res, _ = self.dataloader.dataset.evaluate(results, logger=runner.logger, **self.eval_kwargs)
        writer.add_scalar('Dice',eval_res['mDice'],runner.epoch+1)
        writer.add_scalar('Aji',eval_res['mAji'],runner.epoch+1)
        writer.add_scalar('PQ',eval_res['mPQ'],runner.epoch+1)
        for name, val in eval_res.items():
            runner.log_buffer.output[name] = val
        runner.log_buffer.ready = True

        if self.save_best is not None:
            if self.key_indicator == 'auto':
                # infer from eval_results
                self._init_rule(self.rule, list(eval_res.keys())[0])
            return eval_res[self.key_indicator]

        return None

    def _do_evaluate(self, runner):
        """perform evaluation and save ckpt."""
        if not self._should_evaluate(runner):
            return

        from tiseg.apis import single_gpu_test
        results = single_gpu_test(runner.model, self.dataloader, pre_eval=True)

        runner.log_buffer.clear()
        runner.log_buffer.output['eval_iter_num'] = len(self.dataloader)
        key_score = self.evaluate(runner, results)
        if self.save_best:
            self._save_ckpt(runner, key_score)


class DistEvalHook(_DistEvalHook):
    """Distributed EvalHook, with efficient test support.
    Args:
        by_epoch (bool): Determine perform evaluation by epoch or by iteration.
            If set to True, it will perform by epoch. Otherwise, by iteration.
            Default: False.
    Returns:
        list: The prediction results.
    """

    greater_keys = ['mIoU', 'mAcc', 'aAcc']

    def __init__(self, *args, custom_intervals=None, custom_milestones=None, by_epoch=False, **kwargs):
        super().__init__(*args, by_epoch=by_epoch, **kwargs)
        if custom_intervals is not None and custom_milestones is not None:
            self.custom_intervals = custom_intervals
            self.custom_milestones = custom_milestones
        else:
            self.custom_intervals = []
            self.custom_milestones = []

    def _should_evaluate(self, runner):
        """Judge whether to perform evaluation.
        Here is the rule to judge whether to perform evaluation:
        1. It will not perform evaluation during the epoch/iteration interval,
           which is determined by ``self.interval``.
        2. It will not perform evaluation if the start time is larger than
           current time.
        3. It will not perform evaluation when current time is larger than
           the start time but during epoch/iteration interval.
        Returns:
            bool: The flag indicating whether to perform evaluation.
        """
        if self.by_epoch:
            current = runner.epoch
            check_time = self.every_n_epochs
        else:
            current = runner.iter
            check_time = self.every_n_iters

        interval = self.interval
        for i, m in zip(self.custom_intervals, self.custom_milestones):
            if (current + 1) >= m:
                interval = i
            else:
                break

        if self.start is None:
            if not check_time(runner, interval):
                # No evaluation during the interval.
                return False
        elif (current + 1) < self.start:
            # No evaluation if start is larger than the current time.
            return False
        else:
            # Evaluation only at epochs/iters 3, 5, 7...
            # if start==3 and interval==2
            if (current + 1 - self.start) % interval:
                return False

        return True

    def evaluate(self, runner, results):
        """Evaluate the results.

        Args:
            runner (:obj:`mmcv.Runner`): The underlined training runner.
            results (list): Output results.
        """
        eval_res, _ = self.dataloader.dataset.evaluate(results, logger=runner.logger, **self.eval_kwargs)
        writer.add_scalar('Dice',eval_res['mDice'],runner.epoch+1)
        writer.add_scalar('Aji',eval_res['mAji'],runner.epoch+1)
        writer.add_scalar('PQ',eval_res['mPQ'],runner.epoch+1)
        for name, val in eval_res.items():
            runner.log_buffer.output[name] = val
        runner.log_buffer.ready = True

        if self.save_best is not None:
            if self.key_indicator == 'auto':
                # infer from eval_results
                self._init_rule(self.rule, list(eval_res.keys())[0])
            return eval_res[self.key_indicator]

        return None

    def _do_evaluate(self, runner):
        """perform evaluation and save ckpt."""
        # Synchronization of BatchNorm's buffer (running_mean
        # and running_var) is not supported in the DDP of pytorch,
        # which may cause the inconsistent performance of models in
        # different ranks, so we broadcast BatchNorm's buffers
        # of rank 0 to other ranks to avoid this.
        if self.broadcast_bn_buffer:
            model = runner.model
            for name, module in model.named_modules():
                if isinstance(module, _BatchNorm) and module.track_running_stats:
                    dist.broadcast(module.running_var, 0)
                    dist.broadcast(module.running_mean, 0)

        if not self._should_evaluate(runner):
            return

        from tiseg.apis import multi_gpu_test
        results = multi_gpu_test(runner.model, self.dataloader, pre_eval=True)

        runner.log_buffer.clear()

        if runner.rank == 0:
            print('\n')
            runner.log_buffer.output['eval_iter_num'] = len(self.dataloader)
            key_score = self.evaluate(runner, results)

            if self.save_best:
                self._save_ckpt(runner, key_score)
